import React, {Component} from 'react';
import Main from './app/component/Main';


export default class App extends React.Component {
  render() {
    return (
      <Main/>
    );
  }
}


